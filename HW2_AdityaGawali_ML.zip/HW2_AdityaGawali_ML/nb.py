import os
import sys
import collections
import re
import math
import copy
from nltk.stem import PorterStemmer 
from nltk.tokenize import word_tokenize

classes = ['spam','ham']
stopWordsFile = 'stopwords.txt'
portStemmer= PorterStemmer()


def getInput():
    training_file = sys.argv[1]
    testing_file = sys.argv[2]
    
    return training_file,testing_file

def stemText(lines):
    stemTextVal=''

    for line in lines:
        words = word_tokenize(line.lower())
        for word in words:
            stemTextVal = stemTextVal + portStemmer.stem(word) + ' '
    
    return stemTextVal

class TextData(object):
    calc_label = ""
    true_label = ""
    text_val = ""
    wordCount = {}

    def __init__(self,true_label, text_val, wordCount):
        self.true_label = true_label
        self.text_val = text_val
        self.wordCount = wordCount


def calc_freq(text):
    regex=r'\w+'
    return dict(collections.Counter(re.findall(regex, text)))

def getDataFromInput(input_file):
    data= {}
    for label_word in os.listdir(input_file):
        directory = os.path.join(input_file, label_word)
        if(os.path.isdir(directory)):
            for file_location in os.listdir(directory):
                file_path = os.path.join(directory, file_location)
                if(os.path.isfile(file_path)):
                    file_pointer = open(file_path, 'r', encoding='latin-1')
                    lines=file_pointer.readlines()
                    text= stemText(lines)
                    data.update({file_path: TextData(label_word, text, calc_freq(text))})

    return data

def removeStopWords(input_text):

    file_pointer = open(stopWordsFile, 'r')
    stopWords=file_pointer.readlines()
    file_pointer.close()

    filter_stopwords_text = copy.deepcopy(input_text)
    count =0
    for stopWord in stopWords:
        for filterWord in filter_stopwords_text:
            if stopWord in filter_stopwords_text[filterWord].wordCount:
                del filter_stopwords_text[filterWord].wordCount[stopWord]
    
    return filter_stopwords_text

def getWordList(input_data):

    wordList = []
    stemmedText=""
    for i in input_data:
        stemmedText += input_data[i].text_val
    for i in calc_freq(stemmedText):
        wordList.append(i)
    return wordList
    

def calc_docCountandText(input_data, class_label):
    docCount=0
    docText=""
    for i in input_data:
        if input_data[i].true_label == class_label:
            docText +=input_data[i].text_val
            docCount += 1
    return docCount,docText

def calc_probabilityList(wordList,word_Freq,class_label,docText):
    probabilityList = {}
    wordTextAndFreqLength=len(docText)+len(word_Freq)
    for word in wordList:
        if word in word_Freq:
            probabilityList.update({class_label+'_'+word:(float((word_Freq[word]+1.0)) / float(wordTextAndFreqLength))})
        else:
            probabilityList.update({class_label+'_'+word:(float(1.0) / float(wordTextAndFreqLength) )})
    
    return probabilityList

    
def train_model(input_data):

   wordList= getWordList(input_data)
   document_obj_length=len(input_data)
   probabilityList = {}
   priors={}


   for class_label in classes:
       docCount=0
       docText=""
       docCount,docText = calc_docCountandText(input_data,class_label)
       priors[class_label] = float(docCount)/float(document_obj_length)
       word_Freq= calc_freq(docText)
       probabilityList.update(calc_probabilityList(wordList,word_Freq,class_label,docText))
    
   return probabilityList,priors
    
def predictClassLabel(data_point,probabilityList,priors):
    classValues={}
    for class_label in classes:
        classValues[class_label] = math.log(float(priors[class_label]))
        for word in data_point.wordCount:
            if (class_label + '_' + word) in probabilityList:
                classValues[class_label] += float(math.log(probabilityList[class_label+'_'+word]))
    
    if classValues['ham'] > classValues ['spam']:
        return 'ham'
    else:
        return 'spam'


def getCorrectPredictions(filter_testing_data,probabilityList,priors):
    correctPredVal=0
    for i in filter_testing_data:
       class_val = predictClassLabel(filter_testing_data[i],probabilityList,priors)
       if class_val == filter_testing_data[i].true_label:
           correctPredVal = correctPredVal+1
    return correctPredVal

def getAccuracy(filter_testing_data,correctLabelCount):
    return round((100*correctLabelCount/len(filter_testing_data)),3)



if __name__=='__main__':

    training_file, testing_file = getInput()

    training_data = getDataFromInput(training_file)
    testing_data = getDataFromInput(testing_file)

    filter_training_data = removeStopWords(training_data)
    filter_testing_data = removeStopWords(testing_data)


    probabilityList,priors=train_model(filter_training_data)

    #Training accuracy w/o stop words
    correctTrainLabelCount=getCorrectPredictions(filter_training_data,probabilityList,priors)
    accuracyTrain= getAccuracy(filter_training_data,correctTrainLabelCount)

    print(f'Accuracy of training data without stopwords is {accuracyTrain}')

    #Testing accuracy w/o stop words
    correctLabelCount=getCorrectPredictions(filter_testing_data,probabilityList,priors)
    accuracy= getAccuracy(filter_testing_data,correctLabelCount)

    print(f'Accuracy of testing data without stopwords is {accuracy}')

    probabilityStopList,stoppriors=train_model(training_data)

    #Training accuracy with stop words
    correctTrainStopLabelCount=getCorrectPredictions(training_data,probabilityStopList,stoppriors)
    accuracyStopTrain= getAccuracy(training_data,correctTrainStopLabelCount)

    print(f'Accuracy of training data with stopwords is {accuracyStopTrain}')

    #Testing accuracy with stop words
    correctTestStopLabelCount=getCorrectPredictions(testing_data,probabilityStopList,stoppriors)
    accuracyStopTest= getAccuracy(testing_data,correctTestStopLabelCount)

    print(f'Accuracy of testing data with stopwords is {accuracyStopTest}')

    file_pointer = open("results.txt", "w")
    file_pointer.write("Training :" + str(accuracyTrain))
    file_pointer.write("\n")
    file_pointer.write("Test_with_stopwords :" + str(accuracyStopTest))
    file_pointer.write("\n")
    file_pointer.write("Test_without_stopwords :" + str(accuracy))
    file_pointer.close()



