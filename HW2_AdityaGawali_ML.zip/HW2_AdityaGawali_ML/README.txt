To run the code use the command:

python nb.py train test

OR(if multiple python version installed) 

python3 nb.py train test 

Output will be in results.txt

My code is running on local machine with python 3. I am facing issue running on remote.cs.binghamton due to an nltk package issue. The package seems to be installed but is linked with python2 version and not with the python 3 version. Once this issue is fixed my code will run on remote machine.

Adiya Gawali
B00851039